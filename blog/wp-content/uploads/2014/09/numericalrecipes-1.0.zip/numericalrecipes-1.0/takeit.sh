#!/usr/bin/env bash
# You need ghostscript installed, and wget

echo 'Downloading from  http://www.haoli.org'
wget --no-clobber -c -i ./download

echo 'Building the PDF'
gs -dNOPAUSE -sDEVICE=pdfwrite -sOUTPUTFILE=NumericalRecipes.pdf -dBATCH `cat ./makedel`

rm `cat ./makedel`
exit 0
